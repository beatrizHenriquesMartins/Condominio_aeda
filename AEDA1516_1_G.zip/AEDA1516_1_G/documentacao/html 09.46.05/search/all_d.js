var searchData=
[
  ['removecliente',['removeCliente',['../class_condominio.html#ac62185f435dd9c3538a795aa7908beac',1,'Condominio']]],
  ['removeempregado',['removeEmpregado',['../class_servico.html#af2d0e60b4f9b4c1a3e9c545d00a87659',1,'Servico']]],
  ['removehabitacao',['removeHabitacao',['../class_cliente.html#af50893954314bc62ee0cef46e33bbb60',1,'Cliente']]],
  ['requisitaempregado',['requisitaEmpregado',['../class_condominio.html#a5eec0c5c3a1cb566332431939bcbcb56',1,'Condominio']]],
  ['requisitaservico',['requisitaServico',['../class_condominio.html#adb5c91a9114dbc1c0f3c8c3e9f835152',1,'Condominio']]]
];
